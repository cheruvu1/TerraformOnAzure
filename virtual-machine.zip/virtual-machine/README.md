# First steps

## Finding images
```
az vm image list -p "Canonical"
az vm image list -p "Microsoft"
```
